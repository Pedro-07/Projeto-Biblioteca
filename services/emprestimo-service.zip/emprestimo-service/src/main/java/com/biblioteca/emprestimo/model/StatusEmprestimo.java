package com.biblioteca.emprestimo.model;

public enum StatusEmprestimo {
    ATIVO,
    ATRASADO,
    FINALIZADO;
}
